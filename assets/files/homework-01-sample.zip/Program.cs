// Placeholder sample file — replace with your own homework project.
using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("This is a placeholder homework file.");
    }
}
