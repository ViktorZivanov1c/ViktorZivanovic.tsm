Sample Homework Project (placeholder)
======================================

This is a placeholder ZIP used to demonstrate the homework
download system on the Notebook portfolio site.

Replace this file with your own project folder before zipping,
e.g.:

  MyHomework01/
    Program.cs
    README.md

Then reference the new zip's path in assets/js/data-homework.js.
